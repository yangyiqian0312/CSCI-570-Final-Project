g++ -std=c++11 7061834756_7999726658_3452732650_basic.cpp
./a.out input.txt 