g++ -std=c++11 7061834756_7999726658_3452732650_efficient.cpp
./a.out input.txt 